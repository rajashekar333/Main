#! /bin/bash

#
#  Install script for Atlas Client
#  Copyright Comcast Corp 2012
#

DIR="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
yum --nogpgcheck -y  install ${DIR}/*.rpm
RUBY=/app/interpreters/ruby/1.9.3
${RUBY}/bin/gem install --no-rdoc --no-ri --local ${DIR}/*.gem

# Make the executable link in /sbin
if [ -e /sbin/atlas-client ]
then
  rm -f /sbin/atlas-client
fi
ln -s ${RUBY}/bin/atlas-client /sbin/atlas-client

if [ -e /sbin/atlas-client ]
then
  /sbin/atlas-client f -f
fi
